//
//  ViewController.m
//  GoogleMapDemo
//
//  Created by aoni on 2017/11/28.
//  Copyright © 2017年 cft. All rights reserved.
//

#import "ViewController.h"
#import <GoogleMaps/GoogleMaps.h>
#import "Model.h"

@interface ViewController ()

@property (nonatomic, strong)   GMSPolyline *polyline;
@property (nonatomic, strong) GMSMapView *mapView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self addMap];
    
    [self addPolyLine];
}

- (void)addPolyLine{
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"gps" ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:filePath];
    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
    
    NSArray *gpsArr = [json objectForKey:@"gps"];
    NSLog(@"cft-json %@",json);
    GMSMutablePath *path = [GMSMutablePath path];
    for (NSUInteger i = 0; i < gpsArr.count; i++) {
        NSDictionary *info = [gpsArr objectAtIndex:i];
        
        //Model *model = [gpsArr objectAtIndex:i];
        
        CLLocationDegrees lat = [[info objectForKey:@"lat"] doubleValue];
        CLLocationDegrees lng = [[info objectForKey:@"lon"] doubleValue];
        NSLog(@"cft-lat:%f lon:%f",lat,lng);
        [path addLatitude:lat longitude:lng];
    }
    
    _polyline = [GMSPolyline polylineWithPath:path];
    _polyline.strokeWidth = 6.0;
    _polyline.strokeColor = [UIColor redColor];
    _polyline.geodesic = YES;
    _polyline.map = _mapView;
    
    NSLog(@"cft-_polyline %@",_polyline);
}

- (void)addMap{
    GMSCameraPosition *camera = [GMSCameraPosition cameraWithLatitude:22.580279
                                                            longitude:113.920376
                                                            zoom:16.0];
    GMSMapView *mapView = [GMSMapView mapWithFrame:CGRectZero camera:camera];
    mapView.myLocationEnabled = YES;
    self.mapView = mapView;
    self.view = mapView;
    
    // Creates a marker in the center of the map.
    GMSMarker *marker = [[GMSMarker alloc] init];
    marker.position = CLLocationCoordinate2DMake(22.5795, 113.921071);
    marker.title = @"ShenZhen";
    marker.snippet = @"China";
    marker.map = mapView;
    
    GMSMarker *endPoint = [[GMSMarker alloc] init];
    endPoint.position = CLLocationCoordinate2DMake(22.579307, 113.921146);
    endPoint.map = mapView;
}





@end
